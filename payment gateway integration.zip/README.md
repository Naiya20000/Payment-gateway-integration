# Payment-Gateway-Integration
A simple website where payment gateway is integrated.  There will be a simple donate button on homepage. On clicking the donate button, the user will land on the payment page where user can select the amount to be paid and the payment type.  Once the payment is done and invoice will be generated and email will be sent to the user for the payment received. The invoice will contain the amount.
Website: https://tsf-ngo.000webhostapp.com/
